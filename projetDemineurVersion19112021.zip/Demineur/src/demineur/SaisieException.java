package demineur;

public class SaisieException extends Exception {

}
